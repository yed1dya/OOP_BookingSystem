package users;

public interface Subscriber {
    void notify(String message);
}
