package users;

public interface User {
    String setFirstName(String s);
    String setLastName(String lastName);
    String setID(String ID);
    String setPhone(String phone);
    String setEmail(String email);
}
