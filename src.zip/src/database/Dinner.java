package database;

public class Dinner extends HotelAmenity{
    public Dinner(String name) {
        super(name);
    }
    public Dinner(){
        this("Dinner");
    }
}
