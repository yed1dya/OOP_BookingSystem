package database;

public class Lunch extends HotelAmenity{
    public Lunch(String name) {
        super(name);
    }
    public Lunch(){
        this("Lunch");
    }
}
