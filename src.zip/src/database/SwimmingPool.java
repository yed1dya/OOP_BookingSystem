package database;

public class SwimmingPool extends HotelAmenity{
    public SwimmingPool(String name) {
        super(name);
    }
    public SwimmingPool(){
        this("Swimming Pool");
    }
}
