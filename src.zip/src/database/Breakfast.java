package database;

public class Breakfast extends HotelAmenity{
    public Breakfast(String name) {
        super(name);
    }
    public Breakfast(){
        this("Breakfast");
    }
}
