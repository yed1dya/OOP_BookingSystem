package exceptions;

public class NoRoomsFoundException extends Throwable{
    public NoRoomsFoundException(String s){
        super(s);
    }
}
