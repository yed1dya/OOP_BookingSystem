package exceptions;

public class RoomExistsException extends Throwable {
    public RoomExistsException(String s){
        super(s);
    }
}
