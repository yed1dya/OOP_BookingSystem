package exceptions;

public class NullParamException extends Throwable{
    public NullParamException(String s){
        super(s);
    }
}
