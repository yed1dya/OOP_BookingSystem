package exceptions;

public class NoSuchRoomException extends Throwable{
    public NoSuchRoomException(String s){
        super(s);
    }
}
